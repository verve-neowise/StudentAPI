package uz.data.studentapi

class Student(
    val id: Int,
    val name: String
)

class StudentList : ArrayList<Student>()